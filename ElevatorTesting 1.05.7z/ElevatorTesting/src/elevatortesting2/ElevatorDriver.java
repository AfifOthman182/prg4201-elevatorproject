/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elevatortesting2;

/**
 *
 * @author Asher
 */
public class ElevatorDriver {

    
        public static void main(String[] args){
            ElevatorMutex e1 = new ElevatorMutex();
            Person p = new Person(4, 1, 1, e1);
            p.start();
        }

}
