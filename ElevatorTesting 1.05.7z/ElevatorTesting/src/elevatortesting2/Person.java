/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elevatortesting2;

/**
 *
 * @author Asher
 */
public class Person extends Thread {
    
    private int destinationFloor;
    private int currentFloor;
    private int state;
    int elevatorArrivalStatus;
    //State of player - do we need need idk? maybe
    //1 - they not done anything
    //2 - they moviung up in elev.
    //3 - movingg down.
    //4 - arrived
    
    //Elevator Object
    ElevatorMutex m = new ElevatorMutex();
    
    //Person Constructor
    public Person(int destinationFloor, int current, int state, ElevatorMutex m){
        this.destinationFloor = destinationFloor;
        currentFloor = current;
        this.state = state;
        System.out.println("Person has been created");
    }
    
    public void run(){
        callElevator();
        enterElevator();
        try {
            //This code is for the elevator to go to its destination floor.
            elevatorArrivalStatus = m.elevator1(destinationFloor);
            //m.elevator1 will return 1 if the elevator is successful in arriving the person to its destiantion, it will return something else if something has happened.
        } catch (InterruptedException e) {

        }
//        if(destinationFloor == 2 && m.e1CurrentFloor == 2 && state==1){
//           
//        }
        if(elevatorArrivalStatus == 1){
            System.out.println("Player has arrived to their destination!");
        }
        
    }
    
    public void callElevator(){
        //This will make the elevator go to the player's current position
        m.e1CallRequest(currentFloor);
    }
    
    public void getOutElevator(){
        System.out.println("Player has gotten out of the elvator");
    }
    
    public void enterElevator(){
        System.out.println("Player has entered the elevator");
  
    }
    
    
}
