/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package elevatortesting2;

/**
 *
 * @author Asher
 */
public class ElevatorMutex {

    int e1Destination, e2Destination, e1Weight, e2Weight, e1CurrentFloor = 3, e2CurrentFloor, e1State, e2State;

    public synchronized int elevator1(int personDestinationFloor) throws InterruptedException {
        
        goToDestination(personDestinationFloor);
        if (personDestinationFloor == e1CurrentFloor) {
            dropOffArrival();
            return 1;
        }
        return 0;
    }
    
    public synchronized int elevator2(int personDestinationFloor) throws InterruptedException {
//        goToDestination(personDestinationFloor);
//        if (personDestinationFloor == e1CurrentFloor) {
//            dropOffArrival();
//            return 1;
//        }
        return 0;
    }


    public void e1CallRequest(int getPlayerCurrentFloor) {
        //If elevator  floor is greater than the person's current floor (For example: Elevator at FLOOR 3, Person at FLOOR 1)
        //elevator will descend until Elevator current Floor == Player Current Floor
        //Vice versa when elevator floor is lower than person's current floor position.
        if (e1CurrentFloor > getPlayerCurrentFloor) {
            //debug
            //System.out.println("Test");
            //System.out.println("e1CurrentFloor : " + e1CurrentFloor);
            //System.out.println("getPlayerCurrentFloor : " + getPlayerCurrentFloor);
            
            //Elevator Descends until it meets person's current floor.
            while (e1CurrentFloor != getPlayerCurrentFloor) {
                e1CurrentFloor--;
                System.out.println("Elevator is moving down and is now at Floor " + e1CurrentFloor);
            }
            System.out.println("Elevator 1 has arrived");
        } 
    }

    public void goToDestination(int personDestinationFloor) {
        //We want the elevator to go to the person's destination floor. So check if elevator's current floor position 
        // is lower or higher than person's destination floor. (Example: Elevator floor: 2, Person Destination Floor: 4) Elevator needs to go to floor 4 so we increment its current position 
        //If so, ascend, if not, descend.
        if (e1CurrentFloor < personDestinationFloor) {
            //Elevator ascends until it reaches person's destination floor.
            while (e1CurrentFloor != personDestinationFloor) {
                e1CurrentFloor++;
                System.out.println("Elevaotr is moving up and is now at Floor " + e1CurrentFloor);
            }
        }
        //System.out.println("Debug: goToDestination");
    }

    public void dropOffArrival() {
        System.out.println("Elevator has arrived to its destination. Dropping off passengers");
    }

}
