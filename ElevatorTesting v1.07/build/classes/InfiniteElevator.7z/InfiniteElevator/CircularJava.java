package InfiniteElevator;

import java.util.LinkedList;

public class CircularJava {

    public static void main(String[] args)
            throws InterruptedException {

        BuildingFloor pc = new BuildingFloor();

        pc.distributePeople();
        Elevator1 e1 = new Elevator1(pc);
        Elevator2 e2 = new Elevator2(pc);

        e1.start();
        e2.start();

        e1.join();
        e2.join();
    }
}
